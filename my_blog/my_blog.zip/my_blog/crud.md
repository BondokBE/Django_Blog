CREATE -- post -- MAKE NEW
RETRIEVE -- GET -- List/Search
Update -- Put/Patch -- Edit
Delete -- Delete -- Deletion