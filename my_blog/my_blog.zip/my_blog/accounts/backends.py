from django.contrib.auth.models import User

class EmailBackEnd(object):

    def authenticate(self, username=None, password=None, **kwargs):
        

